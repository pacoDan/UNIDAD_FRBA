module ExitCodes (
  exit_bad_server )
where

exit_bad_server :: Int
exit_bad_server = 1
