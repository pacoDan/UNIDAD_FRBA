{-# LANGUAGE DeriveDataTypeable #-}

-- | A newtype around the DNS query timeout, in seconds. Needed for
--   the 'Default' instance.
--
module Timeout
where

import Data.Data (Data)
import System.Console.CmdArgs.Default (Default(..))
import Data.Typeable (Typeable)

newtype Timeout =
  Timeout { seconds :: Int }
  deriving (Data, Show, Typeable)

instance Default Timeout where
  def = Timeout 15
