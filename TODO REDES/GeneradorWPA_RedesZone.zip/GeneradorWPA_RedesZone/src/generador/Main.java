package generador;

/*
 * Este programa ha sido realizado por Sergio de Luz (Bron) para www.redeszone.net
 */

public class Main {

    public static void main(String[] args) {
        Interfaz nuevoGen = new Interfaz();
        nuevoGen.setVisible(true);
    }

}
