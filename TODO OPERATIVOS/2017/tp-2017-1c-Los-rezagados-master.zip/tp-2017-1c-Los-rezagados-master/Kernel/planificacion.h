/*
 * planificacion.h
 *
 *  Created on: 15/5/2017
 *      Author: utnso
 */

#ifndef PLANIFICACION_H_
#define PLANIFICACION_H_

#include "libreriaKernel.h"

pthread_mutex_t mut_detengo_plani;

void planificar();


#endif /* PLANIFICACION_H_ */
