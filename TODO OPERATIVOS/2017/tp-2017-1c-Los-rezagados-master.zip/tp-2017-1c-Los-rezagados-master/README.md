# tp-2017-1c-Los-rezagados


Para agilizar la escritura del path de los scripts en consola

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/consumidor.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/productor.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/creaArchivo.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/leeBorra.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/creaGigante.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/escribirFS.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/leerFS.ansisop



start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/heapbasico.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/heapcompactar.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/heappasado.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/llenandomemoria.ansisop

start /home/utnso/workspace/ansisop-parser/programas-ejemplo/evaluacion-final-esther/Scripts-Prueba/stackoverflow.ansisop

