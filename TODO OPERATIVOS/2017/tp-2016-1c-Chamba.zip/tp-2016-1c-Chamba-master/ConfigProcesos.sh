export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/home/utnso/tp-2016-1c-Chamba/elestac/LIBRERIAS/

export CONSOLA_LOG=/home/utnso/tp-2016-1c-Chamba/elestac/Consola/log.txt
export CONSOLA_CONFIG=/home/utnso/tp-2016-1c-Chamba/elestac/Consola/Consola.txt
export NUCLEO_LOG=/home/utnso/tp-2016-1c-Chamba/elestac/Nucleo/log.txt
export NUCLEO_CONFIG=/home/utnso/tp-2016-1c-Chamba/elestac/Nucleo/Nucleo.txt
export CPU_LOG=/home/utnso/tp-2016-1c-Chamba/elestac/ProcesoCpu/log.txt
export CPU_CONFIG=/home/utnso/tp-2016-1c-Chamba/elestac/ProcesoCpu/ProcesoCpu.txt
export SWAP_LOG=/home/utnso/tp-2016-1c-Chamba/elestac/Swap/log.txt
export SWAP_CONFIG=/home/utnso/tp-2016-1c-Chamba/elestac/Swap/Swap.txt
export UMC_LOG=/home/utnso/tp-2016-1c-Chamba/elestac/UMC/log.txt
export UMC_CONFIG=/home/utnso/tp-2016-1c-Chamba/elestac/UMC/UMC.txt