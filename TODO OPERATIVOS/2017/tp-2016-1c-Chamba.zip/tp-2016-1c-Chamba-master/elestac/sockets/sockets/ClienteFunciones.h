/*
 * socketsClienteFunciones.h
 *
 *  Created on: 18/4/2016
 *      Author: utnso
 */

#ifndef LIBRERIAS_SOCKETSCLIENTEFUNCIONES_H_
#define LIBRERIAS_SOCKETSCLIENTEFUNCIONES_H_
#include <sys/socket.h>
#include <stdint.h>
int AbrirConexion(char *ip, int puerto);


#endif /* LIBRERIAS_SOCKETSCLIENTEFUNCIONES_H_ */
