/*
 * StructsUtiles.c
 *
 *  Created on: 17/5/2016
 *      Author: utnso
 */


