#!/bin/bash
# -*- ENCODING: UTF-8 -*-

echo "Copiando archivos... "
cp FileSystem/scripts\ y\ utilitarios/mfc ~/mfc
cp FileSystem/scripts\ y\ utilitarios/koopa ~/koopa
cp FileSystem/scripts\ y\ utilitarios/Koopa\ Scripts/script-esquema1-server.sh ~/script-esquema1.sh
cp FileSystem/scripts\ y\ utilitarios/Koopa\ Scripts/script1-server.sh ~/script1.sh
echo "DONE!"
