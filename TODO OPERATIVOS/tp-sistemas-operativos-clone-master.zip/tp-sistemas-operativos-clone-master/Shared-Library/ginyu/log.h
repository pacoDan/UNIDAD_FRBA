#ifndef GINYULOG_H_
#define GINYULOG_H_

#include "../commons/log.h"
#include "../commons/string.h"
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

	t_log* logInit(char** argv, char* who);

#endif
