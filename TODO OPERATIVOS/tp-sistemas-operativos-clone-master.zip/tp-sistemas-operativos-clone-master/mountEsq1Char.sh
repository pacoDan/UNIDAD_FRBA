#!/bin/bash
# -*- ENCODING: UTF-8 -*-

./Personaje/Release/mountcharacter.sh esq1_koopa.conf & ./Personaje/Release/mountcharacter.sh esq1_mario.conf & ./Personaje/Release/mountcharacter.sh esq1_luigi.conf
